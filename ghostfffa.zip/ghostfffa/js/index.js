function submitForm() {
    let receipt = document.getElementById('receipt');
    receipt.style.display = "block";
    // let name = document.querySelector('input[name="name"]').value
    // let phone = document.querySelector('input[name="phone"]').value
    // let date = document.querySelector('input[name="date"]').value
    // let age = document.querySelector('input[name="age"]').value
    // let cuisine = document.querySelector('select').value
    // let suggestions = document.querySelector('input[name="suggestions"]').value
    // let why = document.querySelector('input[name="why"]:checked').nextSibling.nodeValue.trim()
    // let rec = document.querySelector('input[name="rec"]:checked').nextSibling.nodeValue.trim()
    // let summ = document.querySelector('input[name="summ"]')



    date_res.innerText = document.getElementById('date').value
    name_res.innerText = document.getElementById('name').value
    summ_res.innerText = document.getElementById('suggestions').value

    return false;
}
